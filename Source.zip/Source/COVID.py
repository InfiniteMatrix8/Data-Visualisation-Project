#The "Pandas" and "MatPlotLib" module, I made use of in order to visualise the data. 
import pandas as pd
import matplotlib.pyplot as plt
import csv


#This loads the CSV file and reads it.
cd = pd.read_csv("Covid Data.csv")


#This prints the first column from the CSV file.
print(cd.head(0))
print()

#This is telling the program only to read from these columns in the CSV file. The columns read are all the age categories, including the date.
print ("These are the age ranges in the record.")

print("------------------------------------------------------")
print("------------------------------------------------------")

#This allows the user to input an age selected from the CSV file.
age_range = input ("Please enter a age you'd like to see COVID data for, for example 'Age[10-14]':")

#This removes any whitespace from the user input.
new_age_range = age_range.strip()

x = cd[["date",new_age_range]]
print(x.head(5)) 
print()

print("------------------------------------------------------")
print("------------------------------------------------------")

#This tells the the earliest and latest date from the records of the CSV file.
months = x[(x["date"] >= "01/01/2020") & (x["date"] <= "05/12/2022")]

print("------------------------------------------------------")
print("------------------------------------------------------")

required_answer = 'Yes'

#This is asking the user if they'd like to see the graph by typing 'Yes'.
answer = input ("Would you like to see the graph? If yes, type 'Yes'.")
answer = answer.strip()

#If the answer is 'Yes', it displays the graph of the user input.
if answer == "Yes":
        print ("Displaying graph...")
        plt.plot(months["date"], months[new_age_range])
plt.xlabel("date")
plt.ylabel(new_age_range)
plt.title ("COVID Data")
ax = plt.gca()
plt.xticks(rotation=90)
for label in ax.get_xaxis().get_ticklabels()[::2]:
    label.set_visible(False)
    plt.show()
    
print("------------------------------------------------------")
print("------------------------------------------------------")
   

#Once the user is finished, this message will come up and allow the user to exit.
exit_program = input ("Enter 0 to exit Covid Record Data Program... Goodbye!")

#When they enter '0', the program will stop.
if exit_program == "0":
        exit()



        



