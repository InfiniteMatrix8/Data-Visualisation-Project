import requests
import json

#This is me setting the URL as a variable to call using the requests module.
response_API = requests.get('https://data.police.uk/api/forces/leicestershire/people')

print("------------------------------------------------------")
print("------------------------------------------------------")

#I made some variables for me to call. The json module is used here to load data in a json format and then read it in text format.
data = response_API.text
json.loads(data)
parse_json = json.loads(data)

#This variable holds all the data from the API.
senior_officer_data = [data]

print("------------------------------------------------------")
print("------------------------------------------------------")
#I've gave the user a choice to either type 'Yes' or return to the previous program.
user_input = input ("Type 'Yes' if you want to see officer data in the UK or type 'No' to exit.")

print("------------------------------------------------------")
print("------------------------------------------------------")

#This prints the API data in a text format.
if user_input == "Yes":
    print(senior_officer_data)
    user_second_input = input ("Press '1' to see crime data.")
    if user_second_input == "1":
        import Crime.py    

#This gives the user the option to exit the program.
elif user_input == "No":
    print("Thank you. Goodbye!")
    exit()
