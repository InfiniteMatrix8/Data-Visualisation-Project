#I used the "Requests" module as well as the "json", module in order to request and print data from the API.
import requests
import json

#This is me setting the URL as a variable to call using the requests module.
response_API = requests.get('https://data.police.uk/api/forces')

print("------------------------------------------------------")
print("------------------------------------------------------")

#This is me demonstrating a connection request to the API. If the number printed out is '200' it is successful.
print(response_API.status_code)
print("The number 200 means a successful connection.")

#I made some variables for me to call. The json module is used here to load data in a json format and then read it in text format.
data = response_API.text
json.loads(data)
parse_json = json.loads(data)

#This variable holds all the data from the API.
forces = [data]

print("------------------------------------------------------")
print("------------------------------------------------------")
#I've gave the user a choice to either type 'Yes' or exit the program since it is still a console menu.
user_input = input ("Type 'Forces' if you want to see data related to polices forces in the UK. Type 'No' to exit.")

print("------------------------------------------------------")
print("------------------------------------------------------")

#This prints the API data in a text format.
if user_input == "Forces":
    print(forces)
    user_second_input = input ("Press '1' to see data about senior officers in the UK.")
    if user_second_input == "1":
        import Officers.py


elif user_input == "No":
    print("Thank you. Goodbye!")
    exit()



