This is my program for Element 2 of the ICA portfolio:

1. For this program, I have used the module 'Pandas' and 'MatPlotLib' so you would need to have that installed on your computer using pip.
2. In order to start the program, you must start with the 'Main Menu.py' and run this in order to get the program working.
3. When the program starts, you will be given an option to display the COVID data or exit, press either number.
4. When prompted, please enter a date you'd like to see (using the correct format) the COVID data for since I have chosen to filter by date.

That's all the information needed, I hope my program runs as best as it can.