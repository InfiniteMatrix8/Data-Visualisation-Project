#I used the "Requests" module as well as the "json", module in order to request and print data from the API.
import requests
import json

#This is me setting the URL as a variable to call using the requests module.
response_API = requests.get('https://data.police.uk/api/crime-categories?date=2011-08')

print("------------------------------------------------------")
print("------------------------------------------------------")

#I made some variables for me to call. The json module is used here to load data in a json format and then read it in text format.
data = response_API.text
json.loads(data)
parse_json = json.loads(data)

#This variable holds all the data from the API.
crime_data = [data]

print("------------------------------------------------------")
print("------------------------------------------------------")
#I've gave the user a choice to either type 'Yes' or exit the program since it is still a console menu.
user_input = input ("Type 'Yes' if you want to see all available crime data in the UK or type 'No' to exit.")

print("------------------------------------------------------")
print("------------------------------------------------------")

#This prints the API data in a text format.
if user_input == "Yes":
    print(crime_data)
    user_second_input = input ("Press '1' to exit program.")
    if user_second_input == "1":
        exit()

#This will exit the program if the user types 'No'.
elif user_input == "No":
    print("Thank you. Goodbye!")
    exit()
