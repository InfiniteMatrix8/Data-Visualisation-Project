print("---------------------------------------------------------------------------------------------------------------------------------------------------------")
print("---------------------------------------------------------------------------------------------------------------------------------------------------------")

print ("Welcome to the Covid Table of Records! Please select one of the following options to start!")

#This is the main console menu in which the user can either choose to display the COVID Data or Exit.
print("1: Select and display COVID case data.")
print("2: Select and display all data queries from Stop and Search.")
print("3: Exit")

#This allows the user to input an option from the Menu above.
option = input("Pick an option from above.")


#Here is where I created a console "menu"for the user. Also includes an "if else statement" to support the branches of decisions.
#IF option 1 is selected, import Python program to display the COVID data, ELIF option 2 will exit, ELSE will force the user to pick the first or second option.

if option == "1":
    import COVID.py

elif option == "2":
    import Police.py
            
elif option == "3":
           print("Goodbye!")
           exit()
           
else:
    print("Restart the program and choose one of the selected options.")
    exit()



